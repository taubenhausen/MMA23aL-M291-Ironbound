/**
 * shop.js — IRONBOUND v2
 * Live-Suche ④ + Filter-Chips ⑤ + Scroll-Animationen
 */
(function () {
  const chips   = document.querySelectorAll('.chip[data-filter]');
  const cards   = document.querySelectorAll('.product-card');
  const countEl = document.getElementById('result-count');

  function updateCount() {
    const n = document.querySelectorAll('.product-card:not(.hidden)').length;
    if (countEl) countEl.textContent = n + ' EINTRÄGE IM INVENTAR';
  }

  chips.forEach(chip => {
    chip.addEventListener('click', function () {
      chips.forEach(c => c.classList.remove('active'));
      this.classList.add('active');
      const f = this.dataset.filter;
      cards.forEach(card => {
        const tags = card.dataset.filter || '';
        card.classList.toggle('hidden', f !== 'alle' && !tags.includes(f));
      });
      updateCount();
    });
  });

  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('keyup', function () {
      const q = this.value.toLowerCase().trim();
      cards.forEach(card => {
        const name = card.querySelector('.pc-name')?.textContent.toLowerCase() || '';
        const cat  = card.querySelector('.pc-cat')?.textContent.toLowerCase() || '';
        card.classList.toggle('hidden', !!q && !name.includes(q) && !cat.includes(q));
      });
      chips.forEach(c => c.classList.remove('active'));
      const all = document.querySelector('[data-filter="alle"]');
      if (all) all.classList.add('active');
      updateCount();
    });
  }

  const range = document.getElementById('price-range');
  const rVal  = document.getElementById('price-val');
  if (range && rVal) range.addEventListener('input', () => rVal.textContent = range.value);

  // Staggered scroll reveal for cards
  cards.forEach((c, i) => {
    c.style.opacity = '0';
    c.style.transform = 'translateY(20px)';
    c.style.transition = `opacity 0.5s ease ${i*0.06}s, transform 0.5s ease ${i*0.06}s`;
  });
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  cards.forEach(c => io.observe(c));

  updateCount();
})();
