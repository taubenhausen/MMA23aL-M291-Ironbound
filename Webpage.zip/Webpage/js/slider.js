/**
 * slider.js — IRONBOUND v2
 * Interaktives Element ④: Image Slider (Homepage + Promotion)
 */
(function () {
  const slides  = document.querySelectorAll('.promo-slide');
  const dots    = document.querySelectorAll('.pdot');
  const btnPrev = document.getElementById('slider-prev');
  const btnNext = document.getElementById('slider-next');
  if (!slides.length) return;

  let current = 0, timer = null;

  function show(idx) {
    if (idx < 0) idx = slides.length - 1;
    if (idx >= slides.length) idx = 0;
    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));
    slides[idx].classList.add('active');
    if (dots[idx]) dots[idx].classList.add('active');
    current = idx;
  }

  if (btnPrev) btnPrev.addEventListener('click', () => { show(current - 1); reset(); });
  if (btnNext) btnNext.addEventListener('click', () => { show(current + 1); reset(); });
  dots.forEach(d => d.addEventListener('click', () => { show(+d.dataset.index); reset(); }));

  function auto() { timer = setInterval(() => show(current + 1), 4500); }
  function reset() { clearInterval(timer); auto(); }
  auto();
})();
