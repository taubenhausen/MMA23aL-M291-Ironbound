/**
 * main.js — IRONBOUND v2.0
 * - Custom cursor
 * - Nav: hide on scroll down, show on scroll up, solid when not at top
 * - Hero weapon: scroll-driven rotation (rotateX + translateY)
 * - Counter animation on scroll
 * - Scroll reveal for sections
 */

(function () {
  'use strict';

  // ── Custom cursor ─────────────────────────────────────────────
  const cursor = document.getElementById('cursor');
  if (cursor) {
    let mx = -100, my = -100;
    document.addEventListener('mousemove', e => {
      mx = e.clientX; my = e.clientY;
      cursor.style.left = mx + 'px';
      cursor.style.top  = my + 'px';
    });
    document.addEventListener('mouseleave', () => cursor.style.opacity = '0');
    document.addEventListener('mouseenter', () => cursor.style.opacity = '1');
  }

  // ── Navigation scroll behaviour ───────────────────────────────
  const nav = document.getElementById('site-nav');
  let lastScrollY = 0;
  let navHovered = false;

  if (nav) {
    nav.addEventListener('mouseenter', () => { navHovered = true; showNav(); });
    nav.addEventListener('mouseleave', () => { navHovered = false; });

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll(); // initial
  }

  function onScroll() {
    const y = window.scrollY;
    const dir = y > lastScrollY ? 'down' : 'up';
    const atTop = y < 80;

    if (!nav) return;

    // solid background when not at top
    nav.classList.toggle('nav-solid', !atTop);

    if (atTop) {
      showNav();
    } else if (dir === 'down' && y > 120 && !navHovered) {
      hideNav();
    } else if (dir === 'up') {
      showNav();
    }

    lastScrollY = y;

    // Weapon parallax + rotation
    const weaponWrap = document.getElementById('weapon-wrap');
    if (weaponWrap) {
      const heroH = document.getElementById('hero')?.offsetHeight || window.innerHeight;
      const progress = Math.min(y / heroH, 1); // 0 → 1

      // rotateX: 0deg at top → -80deg fully scrolled (gun tilts down/away)
      const rotX = progress * -80;
      // subtle Y drift
      const transY = progress * 60;
      // scale slightly
      const scale = 1 - progress * 0.15;
      // fade out
      const opacity = 1 - progress * 1.3;

      weaponWrap.style.transform =
        `perspective(1200px) rotateX(${rotX}deg) translateY(${transY}px) scale(${scale})`;
      weaponWrap.style.opacity = Math.max(0, opacity);
    }

    // Hero content parallax
    const heroContent = document.getElementById('hero-content');
    if (heroContent) {
      heroContent.style.transform = `translateY(${y * 0.25}px)`;
      heroContent.style.opacity = 1 - (y / (window.innerHeight * 0.7));
    }
  }

  function showNav() {
    if (!nav) return;
    nav.classList.remove('nav-hidden');
  }
  function hideNav() {
    if (!nav) return;
    nav.classList.add('nav-hidden');
  }

  // ── Hamburger ─────────────────────────────────────────────────
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      hamburger.classList.toggle('open', open);
      showNav();
    });
    document.addEventListener('click', e => {
      if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
        navLinks.classList.remove('open');
        hamburger.classList.remove('open');
      }
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        navLinks.classList.remove('open');
        hamburger.classList.remove('open');
      }
    });
  }

  // ── Counter animation ─────────────────────────────────────────
  function animateCounter(el) {
    const target = parseInt(el.dataset.target || el.dataset.count || 0);
    const duration = 1800;
    const start = performance.now();

    function update(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out-cubic
      el.textContent = Math.round(eased * target);
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  // ── Intersection Observer ─────────────────────────────────────
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;

      // Scroll reveal
      if (entry.target.classList.contains('reveal')) {
        entry.target.classList.add('revealed');
      }

      // Counter
      if (entry.target.classList.contains('stat-n')) {
        animateCounter(entry.target);
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  // Observe reveal elements
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  // Observe counters
  document.querySelectorAll('.stat-n[data-target]').forEach(el => io.observe(el));

  // Auto-add reveal class to major sections
  document.querySelectorAll(
    '.statement-sect, .cat-sect-head, .feat-sect, .twin-sect, .promo-sect, .nl-sect, .stmt-grid, .feat-grid, .twin-grid, .nl-grid'
  ).forEach((el, i) => {
    if (!el.classList.contains('reveal')) {
      el.classList.add('reveal');
      el.style.transitionDelay = `${i * 0.04}s`;
    }
    io.observe(el);
  });

  // ── Cursor hover state ────────────────────────────────────────
  document.querySelectorAll('a, button').forEach(el => {
    el.addEventListener('mouseenter', () => cursor && cursor.classList.add('hover'));
    el.addEventListener('mouseleave', () => cursor && cursor.classList.remove('hover'));
  });

})();
